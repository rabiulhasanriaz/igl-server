<?php

$DB = 'igl_vas';
$host = 'localhost';
$user = 'root';
$pass = 'FelnaDMA@2007';

$db = 